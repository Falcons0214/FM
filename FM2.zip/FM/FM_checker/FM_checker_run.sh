	./FM_checker ./adaptec1.nodes ./adaptec1.nets ./adaptec1.out
	./FM_checker ./adaptec2.nodes ./adaptec2.nets ./adaptec2.out
	./FM_checker ./adaptec3.nodes ./adaptec3.nets ./adaptec3.out
	./FM_checker superblue1.nodes superblue1.nets ./superblue1.out
	./FM_checker superblue2.nodes superblue2.nets ./superblue2.out
